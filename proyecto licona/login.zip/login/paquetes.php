<?php
    session_start();
    if(!isset($_SESSION['usuario'])){
        echo '
            <script>
                alert("favor de iniciar sesion");
                window.location="formulario.php";
            </script>
        ';
        session_destroy();
        die();
    }
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>VisualVault</title>
  <link rel="icon" href="im/logo.ico" type="image/x-icon">
  
  <link rel="stylesheet" href="style.css">
  
</head>

<body>
    
  <header>
    <div class="container">
        <a href="cerrar.php"  class="axelSimp" >Cerrar Sesion</a>
         <img src="im/us.png" alt="alt" height="25" width="25" style="position: absolute; top: 40px; right: 156px ">
           
       <h1 style="z-index: 1; text-align: center">VisualVault</h1>
       <img src="logo.jpg" alt="Descripción de la imagen" style="position: absolute; top: 30px; right: 750px;" width='50' height='50'>
       <nav>
        <ul style="background-color: black; color: white;">
          <li><a href="ayuda.php">AYUDA</a></li>
          <li><a href="index.php">INICIO</a></li>
          <li><a href="AcercaDe.php">ACERCA DE</a></li>
          <li><a href="contactos.php">CONTACTOS</a></li>
          
              
        </ul>
      </nav>
    </div>
  </header>

  <main>
    <section class="about">
      <div class="container">
        <h2>Proximamente estaran los paquetes para que puedas descargarlos en la pagina.</h2>
        <p>Asi que no te desesperes si no te aparecen para desacargarlos</p>
        <p>Ya que estamos trabajando en ellos además, cuando esten listos habra varios paquetes que seran de tu agrado y puedas descargarlos para el libre uso de estos</p>
        <div class="Xd">        <br><p class="th"> futura descripcion</p> 
        <p> 
          
        <img src="relax.png" alt="Descripción de la imagen">
        <a href="im/hola.rar" download> 
            <button>Paquete de Ciel</button> 
            
        </a>
       
        </p>   
         <img src="trey.png" alt="Descripción de la imagen"><p> futura descripcion</p>
        <a href="im/hola.rar" download> 
            <button>Paquete de Roy</button>
        </a>
         
         <br>
        <img src="tranquila.png" alt="Descripción de la imagen"> <p> futura descripcion</p>
        <a href="im/hola.rar" download> 
            <button>Paquete Ruby</button>
        </a>
        <img src="lo siento.png" alt="Descripción de la imagen"><p> futura descripcion</p>
        <a href="im/hola.rar" download> 
            <button>Paquete AXl</button>
        </a>
        
        </div>
        
      </div>
    </section>
  </main>

  <footer>
    <div class="grupo2">
                <small>&copy; 2024 <b> VisualVault </b> TODOS LOS DERECHOS RESERVADOS </small>
            </div>
            
  </footer>
</body>
</html>
